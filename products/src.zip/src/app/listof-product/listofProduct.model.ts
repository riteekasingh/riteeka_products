export class ProductModel {
  id: number = 0;
  name: string = "";
}
