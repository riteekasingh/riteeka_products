import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import { ApiService } from "../api.service";
import { ProductModel } from "./listofProduct.model";

@Component({
  selector: "app-listof-product",
  templateUrl: "./listof-product.component.html",
  styleUrls: ["./listof-product.component.css"],
})
export class ListofProductComponent implements OnInit {
  formValue!: FormGroup;
  ProductModelObj: ProductModel = new ProductModel();
  listOfProd: any;
  showAdd: boolean = false;

  constructor(private formbuilber: FormBuilder, private api: ApiService) {}

  ngOnInit(): void {
    this.formValue = this.formbuilber.group({
      name: [""],
    });
    this.getProduct();
  }
  addProduct() {
    console.log("modal opened");
  }

  productAdded() {
    this.ProductModelObj.name = this.formValue.value.name;

    this.api.postProduct(this.ProductModelObj).subscribe((res) => {
      console.log(res);
      let ref = document.getElementById("cancel");
      ref?.click();
      this.formValue.reset();
      this.getProduct();
    });
  }
  getProduct() {
    this.api.getProduct().subscribe((res) => {
      console.log(res);
      this.listOfProd = res;
    });
  }

  deleteprod(row: any) {
    this.api.deleteProd(row.id).subscribe((res) => {
      alert("product deleted");
      this.getProduct();
    });
  }
}
