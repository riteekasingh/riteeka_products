import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ListofProductComponent } from "./listof-product/listof-product.component";
import { LaptopComponent } from "./products/laptop/laptop.component";
import { MobileComponent } from "./products/mobile/mobile.component";
import { ProductsComponent } from "./products/products.component";
import { SpeakerComponent } from "./products/speaker/speaker.component";
import { TvComponent } from "./products/tv/tv.component";

const routes: Routes = [
  {
    path: "",
    redirectTo: "products",
    pathMatch: "full",
  },
  {
    path: "products",
    children: [
      { path: "", component: ProductsComponent },
      { path: "Laptop", component: LaptopComponent },
      { path: "Mobile", component: MobileComponent },
      { path: "Tv", component: TvComponent },
      { path: "Speaker", component: SpeakerComponent },
    ],
  },
  { path: "listofproduct", component: ListofProductComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
